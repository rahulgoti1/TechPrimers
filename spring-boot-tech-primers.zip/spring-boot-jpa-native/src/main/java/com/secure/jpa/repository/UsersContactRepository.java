package com.secure.jpa.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.secure.jpa.model.UserContact;

public interface UsersContactRepository extends JpaRepository<UserContact, Integer> {
	List<UserContact> findByPhoneNo(String name);

	@Query(value = "SELECT * FROM user_contact WHERE user_id = ?1 ", nativeQuery = true)
	UserContact findByUserID(String userId);

	List<UserContact> fetchByPhoneNoLength(@Param("length") Long length);
}
