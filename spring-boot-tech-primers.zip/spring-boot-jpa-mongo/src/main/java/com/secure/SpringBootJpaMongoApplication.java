package com.secure;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class SpringBootJpaMongoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootJpaMongoApplication.class, args);
	}
}
