package com.secure.hibernatejpa.resource;

import com.secure.hibernatejpa.repository.BookRepository;
import com.secure.hibernatejpa.repository.MysqlRepository;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class BookResource {

    private MysqlRepository mysqlRepository;
    private BookRepository bookRepository;


    public BookResource(MysqlRepository mysqlRepository, BookRepository bookRepository) {
        this.mysqlRepository = mysqlRepository;
        this.bookRepository = bookRepository;
    }

    @GetMapping("/delete/{id}")
    public int delete(@PathVariable("id") Integer id){
        mysqlRepository.deleteById(id);
        return 1;
    }

    @GetMapping("/book/delete/{id}")
    public int deleteBook(@PathVariable("id") Integer id){
        bookRepository.deleteById(id);
        return 1;
    }
}
