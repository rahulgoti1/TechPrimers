package com.secure.hibernatejpa.repository;

import com.secure.hibernatejpa.entity.BookCategory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MysqlRepository extends JpaRepository<BookCategory, Integer> {
}
