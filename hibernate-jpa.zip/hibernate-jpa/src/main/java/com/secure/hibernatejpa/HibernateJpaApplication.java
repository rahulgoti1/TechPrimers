package com.secure.hibernatejpa;

import com.secure.hibernatejpa.entity.Book;
import com.secure.hibernatejpa.entity.BookCategory;
import com.secure.hibernatejpa.repository.MysqlRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import javax.transaction.Transactional;
import java.util.HashSet;
import java.util.Set;

@SpringBootApplication
public class HibernateJpaApplication implements CommandLineRunner {

    private MysqlRepository mysqlRepository;

    public HibernateJpaApplication(MysqlRepository mysqlRepository) {
        this.mysqlRepository = mysqlRepository;
    }

    public static void main(String[] args) {
        SpringApplication.run(HibernateJpaApplication.class, args);
    }

    @Override
    @Transactional
    public void run(String... args) throws Exception {
        BookCategory categoryA = new BookCategory("Category A");
        Set bookAs = new HashSet<Book>() {{
            add(new Book("Book A1", categoryA));
            add(new Book("Book A2", categoryA));
            add(new Book("Book A3", categoryA));
        }};

        categoryA.setBooks(bookAs);

        BookCategory categoryB = new BookCategory("Category B");
        Set bookBs = new HashSet<Book>() {{
            add(new Book("Book B1", categoryB));
            add(new Book("Book B2", categoryB));
            add(new Book("Book B3", categoryB));
        }};
        categoryB.setBooks(bookBs);

        mysqlRepository.save(categoryA);
        mysqlRepository.save(categoryB);

        // fetch all categories
        for (BookCategory bookCategory : mysqlRepository.findAll()) {
            System.out.println(bookCategory.toString());

        }

        System.out.println("categoryA.getId() => "+categoryA.getId());
        System.out.println("categoryB.getId() => "+categoryB.getId());
//        mysqlRepository.deleteById(categoryA.getId());

    }
}
