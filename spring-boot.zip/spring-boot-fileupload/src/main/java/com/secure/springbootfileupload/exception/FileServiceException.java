package com.secure.springbootfileupload.exception;

public class FileServiceException extends Exception {
    public FileServiceException() {
        super();
    }

    public FileServiceException(String message) {
        super(message);
    }
}
