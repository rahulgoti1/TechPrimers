package com.secure;

import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@SpringBootApplication // same as @Configuration @EnableAutoConfiguration @ComponentScan
public class SpringBootScratchApplication {

	@RequestMapping("/")
	String home() {
		return "Hello World!";
	}

	@RequestMapping(value = "/data/")
	public List<String> data() {
		List<String> list = new ArrayList<>();
		list.add("Rahul Goti");
		list.add("JRP Sol");
		list.add("Share");
		return list;
	}

	public static void main(String[] args) {
		SpringApplication.run(SpringBootScratchApplication.class, args);
	}
}
