package com.secure.springbootmongodb.controller;

import com.secure.springbootmongodb.model.User;
import com.secure.springbootmongodb.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/user")
public class UserController {

    private final Logger logger = LoggerFactory.getLogger(getClass());

    @Autowired
    UserRepository userRepository;

    @RequestMapping(method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
    public void create(@RequestBody User user) {
        logger.info("Saving user");
        userRepository.save(user);
    }

    @RequestMapping(value = "/{id}")
    public User read(@PathVariable String id) {
        logger.info("Getting user with ID: {}.", id);
        return userRepository.findById(id).get();
    }

    @RequestMapping(value = "/all")
    public List<User> read() {
        logger.info("Getting all users.");
        return userRepository.findAll();
    }

    @RequestMapping(method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE)
    public void update(@RequestBody User user) {
        userRepository.save(user);
    }


    @RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
    public void delete(@PathVariable String id) {
        userRepository.deleteById(id);
    }

    public Object getAllUserSettings(@PathVariable String userId) {
        User user = userRepository.findById(userId).get();
        if (user != null) {
            return user.getUserSettings();
        } else {
            return "User not found.";
        }
    }
}
