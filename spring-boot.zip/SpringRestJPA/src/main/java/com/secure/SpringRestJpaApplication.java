package com.secure;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.secure.app.entities.Employee;
import com.secure.app.repository.EmployeeRepository;

@SpringBootApplication
public class SpringRestJpaApplication implements CommandLineRunner {

	@Autowired
	private EmployeeRepository employeeRepository;

	public static void main(String[] args) {
		SpringApplication.run(SpringRestJpaApplication.class, args);
	}

	@Override
	public void run(String... arg0) throws Exception {
		Employee emp = this.getEmployee();
		employeeRepository.save(emp);
	}

	private Employee getEmployee() {
		Employee emp = new Employee();
		// emp.setEmployeeId(1);
		emp.setEmployeeName("RAHUL");
		emp.setEmail("rahul.goti@gmail.com");
		emp.setSalary(810001.11);
		return emp;
	}
}
