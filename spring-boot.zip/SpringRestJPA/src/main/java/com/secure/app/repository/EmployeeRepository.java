package com.secure.app.repository;

import org.springframework.data.repository.CrudRepository;

import com.secure.app.entities.Employee;

public interface EmployeeRepository extends CrudRepository<Employee, Integer> {

}
