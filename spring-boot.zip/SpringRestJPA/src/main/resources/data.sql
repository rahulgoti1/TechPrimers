insert 
    into
        employee_table
        (email, employee_name, salary) 
    values
        ("rahul.goti@gmail.com", "Daud", 85454547);

insert 
    into
        employee_table
        (email, employee_name, salary) 
    values
        ("daud.goti@gmail.com", "Daud1", 95454547);