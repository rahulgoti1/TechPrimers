package com.infotech.swagger;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringRestSwagger2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringRestSwagger2Application.class, args);
	}
}
